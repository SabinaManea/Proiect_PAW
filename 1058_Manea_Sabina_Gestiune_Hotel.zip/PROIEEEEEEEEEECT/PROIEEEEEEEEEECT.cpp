﻿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>
using namespace std;

class Camera
{
private:
	const string NumarCamera;
	bool Televizor;
	int CapacitateaCamerei;
	int NumarPaturi;

public:
	//constructor fara parametri
	Camera() :NumarCamera("000")
	{
		this->Televizor = 0;
		this->CapacitateaCamerei = 0;
		this->NumarPaturi = 0;
	}

	Camera(const string NumarCamera) :NumarCamera(NumarCamera)
	{
		this->Televizor = 0;
		this->CapacitateaCamerei = 0;
		this->NumarPaturi = 0;
	}

	//constructor cu parametri
	Camera(const string NumarCamera, bool Televizor, int CapacitateaCamerei, int NumarPaturi) :NumarCamera(NumarCamera)
	{
		this->Televizor = 0;

		if (CapacitateaCamerei >= 1)
		{
			this->CapacitateaCamerei = CapacitateaCamerei;
		}
		else
		{
			this->CapacitateaCamerei = 0;
		}

		if (NumarPaturi >= 0)
		{
			this->NumarPaturi = NumarPaturi;
		}
		else
		{
			this->NumarPaturi = 0;
		}
	}

	//Metode de acces pentru campurile private
		//getteri
	const string getNumarCamera()
	{
		return this->NumarCamera;
	}

	bool getTelevizor()
	{
		return this->Televizor;
	}

	int getCapacitateaCamerei()
	{
		return this->CapacitateaCamerei;
	}

	int getNumarPaturi()
	{
		return this->NumarPaturi;
	}

	//setteri
	void setTelevizor(bool Televizor)
	{
		this->Televizor = Televizor;
	}

	void setCapacitateaCamerei(int CapacitateaCamerei)
	{
		this->CapacitateaCamerei = CapacitateaCamerei;
	}

	void setNumarPaturi(int NumarPaturi)
	{
		this->NumarPaturi = NumarPaturi;
	}

	//constructor de copiere
	Camera(const Camera& ct) :NumarCamera(ct.NumarCamera)
	{
		this->Televizor = ct.Televizor;
		this->CapacitateaCamerei = ct.CapacitateaCamerei;
		this->NumarPaturi = ct.NumarPaturi;
	}

	//Supraincarcarea operatorului de atribuire
	Camera& operator= (const Camera& ct)
	{
		if (this != &ct)
		{
			this->Televizor = ct.Televizor;
			this->CapacitateaCamerei = ct.CapacitateaCamerei;
			this->NumarPaturi = ct.NumarPaturi;
		}
		return *this;
	}

	//Supraincarcarea operatorilor de citire si afisare
	friend ostream& operator<<(ostream& out, const Camera& ct)
	{
		cout << "Numar camera: ";
		out << ct.NumarCamera << " ";
		cout << endl;
		cout << "Capacitatea camerei: ";
		out << ct.CapacitateaCamerei << " ";
		cout << endl;
		cout << "Numar paturi: ";
		out << ct.NumarPaturi << " ";
		cout << endl;
		cout << "Televizor: ";
		out << ct.Televizor << endl;
		return out;
	}

	friend istream& operator>>(istream& in, Camera& ct)
	{
		cout << "Introduceti televizor: ";
		in >> ct.Televizor;
		cout << "Introduceti capacitatea camerei: ";
		in >> ct.CapacitateaCamerei;
		cout << "Introduceti numarul de paturi: ";
		in >> ct.NumarPaturi;

		return in;
	}

	//destructor
	~Camera()
	{

	}
};

enum Produs { suc, vin, paste, pizza };

//PRIMA CLASA DERIVATA
class RoomService :public Camera
{
private:
	Produs* Comanda;
	int NrProduseComandate;

public:
	//constructor fara parametri
	RoomService()
	{
		this->NrProduseComandate = 0;
		this->Comanda = nullptr;
	}

	//constructor cu parametri
	RoomService(Produs* Comanda, int NrProduseComandate)
	{
		if (NrProduseComandate >= 0)
		{
			this->NrProduseComandate = NrProduseComandate;
			this->Comanda = new Produs[this->NrProduseComandate];
			for (int i = 0;i < this->NrProduseComandate;i++)
			{
				this->Comanda[i] = Comanda[i];
			}
		}
		else
		{
			this->NrProduseComandate = 0;
		}
	}

	//Metode de acces pentru campurile private
		//getteri
	Produs* getComanda(Produs* Comanda)
	{
		return this->Comanda = Comanda;
	}

	int getNrProduseComandate(int NrProduseComandate)
	{
		return this->NrProduseComandate = NrProduseComandate;
	}

	//setteri
	void setComanda(Produs* Comanda)
	{
		if (this->Comanda != nullptr)
		{
			delete[]this->Comanda;
		}
		this->Comanda = Comanda;
	}

	void setNrProduseComandate(int NrProduseComandate)
	{
		this->NrProduseComandate = NrProduseComandate;
	}

	//constructor de copiere
	RoomService(const RoomService& ct)
	{
		if (ct.NrProduseComandate > 0)
		{
			this->NrProduseComandate = ct.NrProduseComandate;
			this->Comanda = new Produs[this->NrProduseComandate];
			for (int i = 0;i < this->NrProduseComandate;i++)
			{
				this->Comanda[i] = ct.Comanda[i];
			}
		}
		else
		{
			this->NrProduseComandate = 0;
		}
	}

	//Supraincarcarea operatorului de atribuire
	RoomService& operator=(const RoomService& ct)
	{
		if (this != &ct)
		{
			delete[] this->Comanda;
			this->Comanda = nullptr;

			if (ct.NrProduseComandate > 0)
			{
				this->NrProduseComandate = ct.NrProduseComandate;
				this->Comanda = new Produs[this->NrProduseComandate];
				for (int i = 0;i < this->NrProduseComandate;i++)
				{
					this->Comanda[i] = ct.Comanda[i];
				}
			}
			else
			{
				this->NrProduseComandate = 0;
			}
		}
		return *this;
	}

	//Supraincarcarea operatorilor de citire si afisare
	friend ostream& operator<<(ostream& out, const RoomService& ct)
	{
		cout << "Numar produse comandate: ";
		out << ct.NrProduseComandate;

		for (int i = 0;i < ct.NrProduseComandate;i++)
		{
			switch (ct.Comanda[i])
			{
			case suc:
				out << "Suc";
				break;
			case vin:
				out << "Vin";
				break;
			case paste:
				out << "Paste";
				break;
			case pizza:
				out << "Pizza";
				break;
			default:
				out << "Suc";
				break;
			}
		}
		cout << endl;

		return out;
	}

	friend istream& operator>>(istream& in, RoomService& ct)
	{
		delete[] ct.Comanda;
		ct.Comanda = nullptr;

		cout << "Introduceti numarul de produse comandate: ";
		in >> ct.NrProduseComandate;

		cout << "Introduceti comanda: ";
		for (int i = 0;i < ct.NrProduseComandate;i++)
		{
			int aux;
			in >> aux;

			switch (aux)
			{
			case suc:
				ct.Comanda[i]= suc;
				break;
			case vin:
				ct.Comanda[i] = vin; 
				break;
			case paste:
				ct.Comanda[i] = paste;
				break;
			case pizza:
				ct.Comanda[i] = pizza;
				break;
			default:
				ct.Comanda[i] = suc;
				break;
			}
		}
	}

	//destructor
	~RoomService()
	{
		if (this->Comanda != nullptr)
		{
			delete[]this->Comanda;
		}
	}
};

//A DOUA CLASA DERIVATA
class CameraDeLux :public Camera
{
private:
	float SuprafataBalcon;
	int CapacitateJacuzzi;

public:
	//constructor fara parametri
	CameraDeLux()
	{
		this->SuprafataBalcon = 0;
		this->CapacitateJacuzzi = 0;
	}

	//constructor cu parametri
	CameraDeLux(float SuprafataBalcon, int CapacitateJacuzzi)
	{
		if (SuprafataBalcon > 0)
		{
			this->SuprafataBalcon = SuprafataBalcon;
		}
		else
		{
			this->SuprafataBalcon = 0;
		}

		if (CapacitateJacuzzi > 0)
		{
			this->CapacitateJacuzzi = CapacitateJacuzzi;
		}
		else
		{
			this->CapacitateJacuzzi = 0;
		}
	}

	//Metode de acces pentru campurile private
		//getteri
	float getSuprafataBalcon()
	{
		return this->SuprafataBalcon;
	}

	int getCapacitateJacuzzi()
	{
		return this->CapacitateJacuzzi;
	}

	//setteri
	void setSuprafataBalcon(float SuprafataBalcon)
	{
		this->SuprafataBalcon = SuprafataBalcon;
	}

	void setCapacitateJacuzzi(int CapacitateJacuzzi)
	{
		this->CapacitateJacuzzi = CapacitateJacuzzi;
	}

	//constructor de copiere
	CameraDeLux(const CameraDeLux& ct)
	{
		this->SuprafataBalcon = ct.SuprafataBalcon;
		this->CapacitateJacuzzi = ct.CapacitateJacuzzi;
	}

	//Supraincarcarea operatorului de atribuire
	CameraDeLux& operator=(CameraDeLux& ct)
	{
		if (this != &ct)
		{
			this->SuprafataBalcon = ct.SuprafataBalcon;
			this->CapacitateJacuzzi = ct.CapacitateJacuzzi;
		}
		return *this;
	}

	//Supraincarcarea operatorilor de citire si afisare
	friend ostream& operator<<(ostream& out, const CameraDeLux& ct)
	{
		cout << "Suprafata Balcon: ";
		out << ct.SuprafataBalcon << " ";
		cout << endl;

		cout << "Capacitate Jacuzzi: ";
		out << ct.CapacitateJacuzzi << " ";
		cout << endl;

		return out;
	}

	friend istream& operator>>(istream& in, CameraDeLux& ct)
	{
		cout << "Introduceti suprafata balconului: ";
		in >> ct.SuprafataBalcon;

		cout << "Introduceti capacitate jacuzzi: ";
		in >> ct.CapacitateJacuzzi;

		return in;
	}

	//destructor
	~CameraDeLux()
	{

	}
};

//O CLASA CARE SA CONTINA UN VECTOR CU ELEMENTELE DE TIPUL CLASEI DE BAZA
class Receptie :public Camera
{
private:
	Camera* Camere;
	string* Client; //numele clientului care sta in acea camera
	bool* Ocupat; //vedem daca e ocupata sau nu camera
	int NrCamere;

public:
	//constructorul fara parametri
	Receptie()
	{
		this->NrCamere = 0;
		this->Client = nullptr;
		this->Ocupat = nullptr;
		this->Camere = nullptr;
	}

	//constructor cu parametri
	 Receptie(Camera* Camere, string* Client, bool* Ocupat, int NrCamere)
	{
		if (NrCamere > 0 && Camere != nullptr && Client != nullptr && Ocupat != nullptr)
		{
			this->NrCamere = NrCamere;
			this->Camere = new Camera[this->NrCamere];
			this->Client = new string[this->NrCamere];
			this->Ocupat = new bool[this->NrCamere];
			for (int i = 0;i < this->NrCamere;i++)
			{
				this->Camere[i] = Camere[i];
				this->Client[i] = Client[i];
				this->Ocupat[i] = Ocupat[i];
			}
		}
		else
		{
			this->NrCamere = 0;
		}

	}

//Metode de acces pentru campurile private
	//getteri 
	 Camera* getCamere()
	 {
		 return this->Camere;
	 }

	 string* getClient()
	 {
		 return this->Client;
	 }

	 bool* getOcupat()
	 {
		 return this->Ocupat;
	 }

	 int getNrCamere()
	 {
		 return this->NrCamere;
	 }

	//setteri
	 void setCamere(Camera* Camere)
	 {
		 if (this->Camere != nullptr)
		 {
			 delete[] this->Camere;
		 }
		 this->Camere = Camere;
	 }

	 void setClient(string* Client)
	 {
		 if (this->Client != nullptr)
		 {
			 delete[] this->Client;
		 }
		 this->Client = Client;
	 }

	 void setOcupat(bool* Ocupat)
	 {
		 if (this->Ocupat != nullptr)
		 {
			 delete[] this->Ocupat;
		 }
		 this->Ocupat = Ocupat;
	 }

	 void setNrCamere(int NrCamere)
	 {
		 this->NrCamere = NrCamere;
	 }

	//constructor de copiere
	 Receptie(const Receptie& ct)
	 {
		 if (ct.NrCamere > 0 && ct.Camere != nullptr && ct.Client != nullptr && ct.Ocupat != nullptr)
		 {
			 this->NrCamere = ct.NrCamere;
			 this->Camere = new Camera[this->NrCamere];
			 this->Client = new string[this->NrCamere];
			 this->Ocupat = new bool[this->NrCamere];
			 for (int i = 0;i < this->NrCamere;i++)
			 {
				 this->Camere[i] = ct.Camere[i];
				 this->Client[i] = ct.Client[i];
				 this->Ocupat[i] = ct.Ocupat[i];
			 }
		 }
		 else
		 {
			 this->NrCamere = 0;
		 }
	 }

	//Supraincarcarea operatorului de atribuire
	 Receptie& operator= (const Receptie& ct)
	 {
		 if (this != &ct)
		 {
			 delete[] this->Camere;
			 this->Camere = nullptr;

			 delete[] this->Ocupat;
			 this->Ocupat = nullptr;

			 delete[] this->Client;
			 this->Client = nullptr;

			 if (ct.NrCamere > 0 && ct.Camere != nullptr && ct.Client != nullptr && ct.Ocupat != nullptr)
			 {
				 this->NrCamere = ct.NrCamere;
				 this->Camere = new Camera[this->NrCamere];
				 this->Client = new string[this->NrCamere];
				 this->Ocupat = new bool[this->NrCamere];
				 for (int i = 0;i < this->NrCamere;i++)
				 {
					 this->Camere[i] = ct.Camere[i];
					 this->Client[i] = ct.Client[i];
					 this->Ocupat[i] = ct.Ocupat[i];
				 }
			 }
			 else
			 {
				 this->NrCamere = 0;
			 }
		 }
		 return *this;
	 }

	//Supraincarcarea operatorilor de citire si afisare
	 friend ostream& operator<<(ostream& out, const Receptie& ct)
	 {
		 cout << "Numarul camerei: ";
		 out << ct.NrCamere;

		 for (int i = 0; i < ct.NrCamere; i++)
		 {
			 cout << "Numarul camerei: ";
			 out << ct.Camere;

			 cout << "Numele clientului: ";
			 out << ct.Client;

			 cout << "E ocupat? ";
			 out << ct.Ocupat;

		 }

		 return out;
	 }

	 friend istream& operator>>(istream& in, Receptie& ct)
	 {
		 delete[] ct.Camere;
		 ct.Camere = nullptr;

		 delete[] ct.Client;
		 ct.Client = nullptr;

		 delete[] ct.Ocupat;
		 ct.Ocupat = nullptr;

		 cout << "Introduceti numarul camerei: ";
		 in >> ct.NrCamere;

		 if (ct.NrCamere > 0) 
		 {
			 ct.Camere = new Camera[ct.NrCamere];
			 ct.Client = new string[ct.NrCamere];
			 ct.Ocupat = new bool[ct.NrCamere];

			 for (int i = 0; i < ct.NrCamere; i++) 
			 {
				 cout << "Introduceti numarul camerei: " << endl;
				 in >> ct.Camere[i];

				 cout << "Introduceti numele clientului: " << endl;
				 in >> ct.Client[i];

				 cout << "Este ocupat? " << endl;
				 in >> ct.Ocupat[i];
			 }
		 }
		 return in;
	 }

	//supraincarcarea operatorului += pentru a adauga un element in vector
	 Receptie& operator+=(const Camera& newCamera)
	 {
		 
		 Camera* newCamere = new Camera[NrCamere + 1];

		 for (int i = 0; i < NrCamere; i++)
		 {
			 newCamere[i] = Camere[i];
		 }

		 newCamere[NrCamere] = newCamera;
		 delete[] Camere;
		 Camere = newCamere;
		 NrCamere++;
		 return *this;
	 }

	//supraincarcarea operatorului -= pentru a elimina un element din vector
	 Receptie& operator-=(const Camera& newCamera)
	 {

		 Camera* newCamere = new Camera[NrCamere - 1];

		 for (int i = 0; i < NrCamere; i++)
		 {
			 newCamere[i] = Camere[i];
		 }

		 newCamere[NrCamere] = newCamera;
		 delete[] Camere;
		 Camere = newCamere;
		 NrCamere--;
		 return *this;
	 }

	//operatorul de acces pe baza de index, pentru citirea unui element din vector de la o pozitie data

	//destructor
	 ~Receptie()
	 {
		 if (this->Camere != nullptr)
		 {
			 delete[] this->Camere;
		 }

		 if (this->Client != nullptr)
		 {
			 delete[] this->Client;
		 }

		 if (this->Ocupat != nullptr)
		 {
			 delete[] this->Ocupat;
		 }
	 }
};

int main()
{
//CLASA DE BAZA
	 //constructor fara parametri
	cout << "Clasa de baza - Constructor fara parametri" << endl;
	Camera cam;
	cout << cam.getNumarCamera() << " ";
	cout << cam.getCapacitateaCamerei() << " ";
	cout << cam.getNumarPaturi() << " ";
	cout << cam.getTelevizor() << endl;

	cam.setCapacitateaCamerei(3);
	cam.setNumarPaturi(3);
	cam.setTelevizor(1);

	cout << cam.getNumarCamera() << " ";
	cout << cam.getCapacitateaCamerei() << " ";
	cout << cam.getNumarPaturi() << " ";
	cout << cam.getTelevizor() << endl << endl;

	//constructor cu parametri
	cout << "Clasa de baza - Constructor cu parametri" << endl;
	Camera cam1("101", 0, 2, 2);
	cout << cam1.getNumarCamera() << " ";
	cout << cam1.getCapacitateaCamerei() << " ";
	cout << cam1.getNumarPaturi() << " ";
	cout << cam1.getTelevizor() << endl << endl;

	//constructor de copiere
	cout << "Clasa de baza - Constructor de copiere" << endl;
	Camera cam2 = cam;
	cout << cam2.getNumarCamera() << " ";
	cout << cam2.getCapacitateaCamerei() << " ";
	cout << cam2.getNumarPaturi() << " ";
	cout << cam2.getTelevizor() << endl << endl;

	//operator=
	cout << "Clasa de baza - Operator =" << endl;
	cam2 = cam1;
	cout << cam2.getNumarCamera() << " ";
	cout << cam2.getCapacitateaCamerei() << " ";
	cout << cam2.getNumarPaturi() << " ";
	cout << cam2.getTelevizor() << endl << endl;

	//operator<<
	cout << "Clasa de baza - Operator<<" << endl;
	cout << cam1 << endl;

	//operator<<
	cout << "Clasa de baza - Operator<<" << endl;
	Camera cam3;
	cout << cam3 << endl;

//PRIMA CLASA DERIVATA


//A DOUA CLASA DERIVATA



//O CLASA CARE SA CONTINA UN VECTOR CU ELEMENTELE DE TIPUL CLASEI DE BAZA
}